/**
 * 参考：
 * https://zhouhao.me/2018/03/19/format-vue-with-prettier-in-vscode/
 * http://www.jk-kj.com/2017/11/03/vscode%E9%85%8D%E7%BD%AEeslint/
 */
module.exports = {
  root: true,
  env: {
    browser: true,
    es6: true
  },
  'extends': [
    'plugin:vue/essential',
    '@vue/standard'
  ],
  rules: {
    'space-before-function-paren': ['error', {
      'anonymous': 'always',
      'named': 'never',
      'asyncArrow': 'always'
    }],
    'object-curly-spacing': [2, 'never'],
    // 关闭语句强制分号结尾
    'semi': [0],
    'indent': 'off',
    'vue/script-indent': ['error', 2, {'baseIndent': 1}]
  },
  parserOptions: {
    parser: 'babel-eslint'
  },
  plugins: []
}

<template>
  <div id="app" class="cover-all" style="overflow: hidden">
    <router-view/>
  </div>
</template>

<style lang="less" type="text/css">
</style>

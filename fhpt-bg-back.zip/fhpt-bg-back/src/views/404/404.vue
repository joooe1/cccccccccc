<template>
  <div class="error-page cover-all re">
    <div class="ab-middle t-center">
      <p class="fs20 white m-b20">404 page not found</p>
      <el-button class="d2-mt" @click="$router.replace({ path: '/' })">
        返回首页
      </el-button>
    </div>
  </div>
</template>

<style lang="less" type="text/css" scoped>
  .error-page {
    background: #303133;
  }
</style>

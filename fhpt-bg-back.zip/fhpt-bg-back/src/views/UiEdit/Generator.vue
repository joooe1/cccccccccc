<template>
  <div class="edit-box full-width re">
    <!--左侧侧边栏-->
    <left-aside class="ab" style="left: 0" :data="mobileData"></left-aside>
    <!--中间显示区域-->
    <div class="full-height center-box widget-form-container">
      <p class="t-right p-r10" style="height: 45px;line-height: 45px;
                background: white;
                border-bottom: 2px solid #e4e7ed;">
         <span class="m-r20" @click="handlePreview">
          <i class="iconfont iconplus-preview"></i>
            预览
        </span>
        <span @click="handleGenerateJson">
          <i class="iconfont iconxianxing-shengcheng"></i>
            生成Json
        </span>
      </p>
      <div class="full-width re" style="height: calc(100% - 45px);overflow-y: auto">
        <phone-form :close.sync='isClose'
                    :data.sync="phoneForm"
                    :select.sync="phoneFormSelect"
                    :frame="mobileFrame"
                    @phonePreview="phoneInfo">
        </phone-form>
      </div>
    </div>
    <!--右侧显示栏-->
    <!--<div class="ab" style="right: 0"></div>-->
    <!--<setting class="ab" style="right: 0"></setting>-->
    <!--预览-->
    <cus-dialog-preview :visible.sync="previewVisible"
                        :modeType="modeType"
                        :options="OptionsData">
    </cus-dialog-preview>
    <!--生成json-->
    <cus-dialog-generate-json :visible.sync="codeJsonVisible"
                              :json="jsonTemplate"
    ></cus-dialog-generate-json>
  </div>
</template>
<script type="text/ecmascript-6">
  import ace from 'ace-builds'
  import 'ace-builds/webpack-resolver' // 在 webpack 环境中使用必须要导入
  import LeftAside from './components/containerComponents/LeftAside'
  import PhoneForm from './components/phone/PhoneForm'
  import CusDialogGenerateJson from './components/containerComponents/cusDialog/GenerateJson'
  // import Setting from './components/containerComponents/Setting'
  // import data from './components/componentsConfig.js' // 原先的模拟数据
  import data from './config/ugGamesConfig.js' // present data
  import CusDialogPreview from './components/containerComponents/cusDialog/Preview'
  export default {
    components: {
      LeftAside,
      PhoneForm,
      CusDialogGenerateJson,
      CusDialogPreview
      // Setting
    },
    data() {
      return {
        mobileData: {},
        isClose: false,
        codeJsonVisible: false,
        phoneForm: {
          // 存储移动端拖拽后的数据
          list: [],
          config: {
            labelWidth: 120,
            labelPosition: 'right',
            backgroundColor: '#F5F5F5'
          },
          style: {
            themeIndex: '0'
          }
        },
        jsonTemplate: {},
        phonePreview: '',
        previewVisible: false,
        phoneWidgetModels: {},
        modeType: 'mobile',
        mobileFrame: 'museUI',
        phoneFormSelect: null,
        remoteFuncs: {
          func_test(resolve) {
            setTimeout(() => {
              const options = [
                {id: '1', name: '1111'},
                {id: '2', name: '2222'},
                {id: '3', name: '3333'}
              ]
              resolve(options)
            }, 2000)
          },
          funcGetToken(resolve) {}
        }
      }
    },
    created() {
      this.init()
    },
    mounted() {},
    computed: {
      OptionsData() {
        // 深加工一下 去除是组件类型是tab-menu 里的列的显示问题
        // 如果列里面的选项分散 按正常数组遍历那样调节
        const options = {
          mobile: {
            data: this.phoneForm,
            remote: this.remoteFuncs,
            value: this.phoneWidgetModels,
            preview: this.phonePreview
          }
        }
        return options
      }
    },
    methods: {
      /**
       * 生成json
       */
      handleGenerateJson() {
        console.log('this.phoneForm >> ', this.phoneForm)
        let jsonData = JSON.parse(JSON.stringify(this.phoneForm))
        let [arrIndex, isdelete] = [[], false]
        // 先判断有没有tab标签页组件 有先进行json格式化
        for (let i = 0, len = jsonData.list.length; i < len; i++) {
          jsonData.list[i].componentType === 'tab-grid' && arrIndex.push(i)
        }
        // 遍历删除每一个节点
        for (let i = 0; i < arrIndex.length; i++) {
          if (!isdelete) {
            jsonData.list.splice(arrIndex[i], 1)
            isdelete = true
          } else {
            jsonData.list.splice(arrIndex[i] - i, 1)
          }
        }
        delete jsonData.config
        delete jsonData.style
        console.log(jsonData)
        this.jsonTemplate = jsonData
        this.codeJsonVisible = true
        this.$nextTick(() => {
          const editor = ace.edit('jsoneditor')
          editor.session.setMode('ace/mode/json')
        })
      },
      /**
       * 选择手机端或电脑端
       */
      phoneInfo(info) {
        this.phonePreview = info
      },
      init() {
        // 获取左侧菜单
        this.getMenu()
      },
      getMenu() {
        console.log(data)
        // this.mobileData = {
        //   'basic': [{
        //     name: '分类',
        //     value: data.mobilebasicComponents
        //   }, {
        //     name: '游戏',
        //     value: data.museUiMobileComponet
        //   }, {
        //     name: '分类综合',
        //     value: data.totalClassify
        //   }],
        //   'business': [{
        //     name: '业务组件',
        //     value: data.museUiMobilebusinessComponents
        //   }]
        // }
        this.mobileData = {
          'basic': [{
            name: '功能导航',
            value: data.totalClassify
          }, {
            name: '彩票',
            value: data.lottery
          }, {
            name: '真人',
            value: data.real
          }, {
            name: '电子',
            value: data.game
          }, {
            name: '棋牌',
            value: data.card
          }, {
            name: '体育',
            value: data.sport
          }]
        }
      },
      /**
       * 预览
       */
      handlePreview() {
        console.log(this.phoneForm)
        console.log('全局值 》》》 ', this.$ug.globalData)
        this.previewVisible = true
      }
    },
    beforeDestroy() {}
  }
</script>

<style type="text/css" lang="less">
  .edit-box {
    .ab {
      top: 0;
      height: 100%;
      width: 250px;
    }
    .center-box {
      width: auto;
      margin: 0 0 0 250px;
    }
    @import "./styles/cover.less";
    @import "./styles/index.less";
  }
</style>

/**
 * 重新将columns 按照预览 显示排序（json 展示）
 * @param arr 数组
 * @returns {*}
 */
export function rearrange(arr) {
  // 第一层遍历
  for (let obj of arr) {
    if (obj.componentType === 'tab-menu' && obj.type === 'grid' && obj.columns && obj.columns.length !== 0) {
      for (let items of obj.columns) {
        if (items.child && items.child.columns && items.child.columns.length !== 0) {
          let [newPosSort, tempArr] = [[], []]
          //  遍历显示那个最长
          for (let child of items.child.columns) {
            child.list.length !== 0 && tempArr.push(child)
            newPosSort.push(child.list.length)
          }
          newPosSort.sort((a, b) => a - b)
          console.log('newPosSort >> ', newPosSort)
          console.log('tempArr >> ', tempArr)
          let newAarry = []
          // 改变当前的columns 数据值
          for (let i = 0; i < newPosSort.length; i++) {
            for (let k = 0; k < tempArr.length; k++) {
              tempArr[k].list[i] && newAarry.push(tempArr[k].list[i])
            }
          }
          console.log(' >>> ', newAarry)
          items.child = newAarry
        }
      }
    }
  }
  return {list: arr}
}
/**
 * 递归去除不必要的数据显示(去除options)
 * @param arr 数组
 * @returns {*}
 */
export function deleteOptions(arr) {
  for (let obj of arr) {
    obj.options && (delete obj.options)
    if (obj.columns) {
      deleteOptions(obj.columns)
    } else if (obj.list) {
      deleteOptions(obj.list)
      if (obj.child) {
        obj.child.options && (delete obj.child.options)
        deleteOptions(obj.child.columns)
      }
    }
  }
  return arr
}
// 预览更改图标排序和生成的json 一致
export function sortView(arr) {
  // 第一层遍历
  for (let obj of arr.list) {
    if (obj.componentType === 'tab-menu' && obj.type === 'grid' && obj.columns && obj.columns.length !== 0) {
      for (let items of obj.columns) {
        if (items.child && items.child.columns && items.child.columns.length !== 0) {
          let [newPosSort, tempArr] = [[], []]
          let temp = JSON.parse(JSON.stringify(items.child.columns))
          //  遍历显示那个最长
          for (let i = 0, listArr = items.child.columns; i < listArr.length; i++) {
            listArr[i].list.length > 0 && tempArr.push(listArr[i])
            newPosSort.push(listArr[i].list.length)
            temp[i].list = []
          }
          newPosSort.sort((a, b) => a - b)
          console.log('newPosSort >> ', newPosSort)
          console.log('tempArr >> ', tempArr)
          let [newAarry, len] = [[], items.child.columns.length]
          // 改变当前的columns 数据值
          for (let i = 0; i < newPosSort.length; i++) {
            for (let k = 0; k < tempArr.length; k++) {
              tempArr[k].list[i] && newAarry.push(tempArr[k].list[i])
            }
          }
          console.log(' >>> ', newAarry)
          // 将排序好的数据重新放回到数组中
          for (let i = 1; i <= newAarry.length; i++) {
            if (i % len) {
              temp[(i % len) - 1].list.push(newAarry[i - 1])
            } else {
              temp[len - 1].list.push(newAarry[i - 1])
            }
          }
          items.child.columns = temp
          console.log(' child.columns >>> ', items.child.columns)
        }
      }
    }
  }
  return arr
}

export function delTabGrid(obj) {
  /* ************* start 去除第一级目录 组件类型是 tab-grid（目前此类型放不到容器中）***************/
  let [arrIndex, isdelete] = [[], false]
  // 先判断有没有tab标签页组件 有先进行json格式化
  for (let i = 0, len = obj.list.length; i < len; i++) {
    obj.list[i].componentType === 'tab-grid' && arrIndex.push(i)
  }
  // 遍历删除每一个节点
  for (let i = 0; i < arrIndex.length; i++) {
    if (!isdelete) {
      obj.list.splice(arrIndex[i], 1)
      isdelete = true
    } else {
      obj.list.splice(arrIndex[i] - i, 1)
    }
  }
  delete obj.config
  delete obj.style
  /* ************* end 去除第一级目录 组件类型是 tab-grid（目前此类型放不到容器中）***************/
  return obj
}

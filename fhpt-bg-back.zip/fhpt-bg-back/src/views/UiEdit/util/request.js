/* eslint-disable no-console */
import axios from 'axios'

/**
 * the Request prefix
 */
// const prefix = '/local/'
// const prefix = '/generator/'
const prefix = ''
const request = axios.create({
  baseURL: prefix,
  headers: {
    'Content-Type': 'application/json;charset=utf-8'
  },
  withCredentials: true,
  params: {}
})
request.interceptors.request.use(
  config => {
    return config
  },
  error => {
    // console.log('error', error)
    return Promise.reject(new Error(error).message)
  }
)
request.interceptors.response.use(
  response => {
    // console.log('.....', response)
    return response.data
  },
  error => {
    // console.log('error', error)
    return Promise.reject(new Error(error).message)
  }
)
export default request

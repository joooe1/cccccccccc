/**
 * 生成子级别的数据项 生成一行几列的栅格
 * @param colContent 标签页导航 外层显示的 columns数组
 * @param fatherKey 标签页导航 的key
 * @param num tabItem 显示为几列
 */
export function gridColumns(colContent, fatherKey, num = 2) {
  let itemList = []
  for (let i = 0; i < colContent.length; i++) {
    let obj = {
      'componentType': 'tab-grid',
      'columns': [],
      'name': '栅格',
      'options': {
        'marginRight': 0,
        'gutter': 0,
        'paddingBottom': 0,
        'backgroundImage': '',
        'paddingRight': 0,
        'marginBottom': 0,
        'paddingTop': 0,
        'align': 'top',
        'paddingLeft': 0,
        'marginTop': 0,
        'marginLeft': 0
      },
      'type': 'grid',
      key: Date.parse(new Date()) + '_' + Math.ceil(Math.random() * 99999),
      parentKey: '',
      grandfatherKey: fatherKey,
      model: ''
    }
    obj.parentKey = colContent[i]['list'][0]['key']
    obj.model = obj.type + '_' + obj.key
    itemList.push(obj)
    itemList[i].columns = Array.from({length: num}, () => ({'list': [], 'span': 24}))
  }
  return itemList
}

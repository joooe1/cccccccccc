<template>
  <div>
    <div :class="this.preview.phoneTypeBgClass"
         :style="this.preview.phoneScaleStyle"></div>
    <div :class="this.preview.phoneTypeClass"
         :style="this.preview.phoneScaleStyle">
      <div class="phone-content" :style="{'backgroundColor':data.config.backgroundColor}" :class="{'phone-widget-empty': data.list.length == 0}">
        <el-form ref="generateMobileForm" :model="models" :rules="rules"
                 :label-position="data.config.labelPosition">
          <template v-for="(item,index) in data.list">
            <template v-if="item.type == 'grid'">
              <el-row
                :key="item.key"
                type="flex"
                :gutter="item.options.gutter ? item.options.gutter : 0"
                :justify="item.options.justify"
                :align="item.options.align"
                :style="{
                marginTop:item.options.marginTop+'px',
                marginBottom:item.options.marginBottom+'px',
                marginLeft:item.options.marginLeft+'px',
                marginRight:item.options.marginRight+'px',
                paddingTop:item.options.paddingTop+'px',
                paddingBottom:item.options.paddingBottom+'px',
                paddingLeft:item.options.paddingLeft+'px',
                paddingRight:item.options.paddingRight+'px',
                backgroundImage:`url(${item.options.imageUrl})`,
                backgroundColor:'#ffffff',
                backgroundSize:'cover'}">
                <el-col v-for="(col, colIndex) in item.columns" :key="colIndex" :span="col.span">
                  <template v-for="(citem,i) in col.list">
                    <phone-genetate-form-item :key="citem.key" :models.sync="models"
                                              :remote="remote" :rules="rules" :widget="citem"
                                              @click.native.stop="changeTab(i,colIndex,index)"
                                              :preview="preview"
                    ></phone-genetate-form-item>
                  </template>
                </el-col>
              </el-row>
            </template>
            <template v-else>
              <phone-genetate-form-item :key="item.key" :models.sync="models"
                                        :remote="remote" :rules="rules" :widget="item"
                                        :preview="preview">
                :label-width="item.config.labelWidth + 'px'"
              </phone-genetate-form-item>
            </template>
          </template>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script>
  import phoneGenetateFormItem from './PhoneGenerateFormItem'

  export default {
    name: 'phone-generate-form',
    components: {
      phoneGenetateFormItem
    },
    props: ['data', 'remote', 'value', 'preview'],
    data() {
      return {
        models: {},
        rules: {}
      }
    },
    created() {
      this.generateModle(this.data.list)
    },
    methods: {
      generateModle(genList) {
        for (let i = 0; i < genList.length; i++) {
          if (genList[i].type === 'grid') {
            genList[i].columns.forEach(item => {
              this.generateModle(item.list)
            })
          } else {
            if (Object.keys(this.value).indexOf(genList[i].model) >= 0) {
              this.models[genList[i].model] = this.value[genList[i].model]
            } else {
              if (genList[i].type === 'blank') {
                this.models[genList[i].model] = genList[i].options.defaultType === 'String' ? '' : (genList[i].options.defaultType === 'Object' ? {} : [])
              } else {
                this.models[genList[i].model] = genList[i].options.defaultValue
              }
            }

            if (this.rules[genList[i].model]) {
              this.rules[genList[i].model] = [...this.rules[genList[i].model], ...genList[i].rules]
            } else {
              this.rules[genList[i].model] = [...genList[i].rules]
            }
          }
        }
      },
      getData() {
        return new Promise((resolve, reject) => {
          this.$refs.generateMobileForm.validate(valid => {
            if (valid) {
              resolve(this.models)
            } else {
              reject(new Error('表单数据校验失败').message)
            }
          })
        })
      },
      changeTab(curIndex, colIndex, outIndex) {
        console.log(454566)
        console.log('curIndex >> ', curIndex)
        console.log('colIndex >> ', colIndex)
        console.log('outIndex >> ', outIndex)
        if (this.data.list[outIndex].componentType === 'tab-menu') {
          // 切换组件数据
          this.$set(this.data.list, outIndex + 1, this.$ug.globalData[this.data.list[outIndex].key][colIndex])
        }
      }
    },
    watch: {
      value: {
        deep: true,
        handler(val) {
          this.models = {...this.models, ...val}
        }
      }
    }
  }
</script>
<style scoped>
  .phone-content{
    padding-bottom: 80px;
  }
</style>

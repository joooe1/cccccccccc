<template>
  <el-form-item :label="widget.options.showLabel ? widget.name:''"
                :prop="widget.model" style="margin-bottom: 0px;">
    <!--dynamic preview selected components -->
    <component :is="this.widget.options.preview"
               :widget="widget" :preview="models"
               @previewHandler="previewHandler"
               style="zoom:.6">
    </component>
  </el-form-item>
</template>

<script>
  export default {
    props: ['widget', 'models', 'rules', 'remote', 'preview'],
    components: {},
    data() {
      return {
        dataModel: this.models[this.widget.model]
      }
    },
    created() {},
    methods: {
      previewHandler(val) {
        this.$emit('update:models', val)
      }
    }
  }
</script>

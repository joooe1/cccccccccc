<template>
  <div class="phone-form">
    <div class="phoneType">
      <el-row>
        <el-col :span="6">&nbsp;</el-col>
        <el-col :span="4">
          <el-select v-model="phoneType" @change="selectPhone" size="mini" style="width: 100%">
            <el-option
              v-for="item in phoneTypeList"
              :key="item.value"
              :label="item.label"
              :value="item">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="4">
          <div class="pixel">{{phoneType.pixel}}</div>
        </el-col>
        <el-col :span="3">
          <el-select v-model="phoneScale" size="mini" @change="selectScale">
            <el-option
              v-for="item in phoneScaleList"
              :key="item.value"
              :label="item.label"
              :value="item">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="6">&nbsp;</el-col>
      </el-row>
    </div>
    <div :class="phoneTypeBgClass" :style="phoneScaleStyle"></div>
    <div :class="phoneTypeClass" :style="phoneScaleStyle">
      <div class="phone-content" :style="{'backgroundColor':widgetData.config.backgroundColor}" :class="{'phone-widget-empty': widgetData.list.length == 0}">
        <el-form :label-position="widgetData.config.labelPosition">
          <draggable
            class="widget-form-list"
            v-model="widgetData.list"
            v-bind="{group:'ug', ghostClass: 'ghost',sort:false}"
            @end="handleMoveEnd"
            :move="checkMove"
            @add="handleWidgetAdd">
            <template v-for="(element, index) in widgetData.list">
              <template v-if="element.type == 'grid'">
                <div
                  v-if="element"
                  class="widget-grid-container data-grid"
                  :key="index"
                  style="position: relative;">
                  <el-row
                    class="widget-grid"
                    type="flex"
                    :class="{active: ((selectWidget && selectWidget.key) == (element.key && element.key)) && (element.componentType != 'tab-grid')}"
                    :gutter="element.options.gutter ? element.options.gutter : 0"
                    :justify="element.options.justify"
                    :align="element.options.align"
                    :style="{
                    marginTop:element.options.marginTop + 'px',
                    marginBottom:element.options.marginBottom + 'px',
                    marginLeft:element.options.marginLeft + 'px',
                    marginRight:element.options.marginRight + 'px',
                    paddingTop:element.options.paddingTop+'px',
                    paddingBottom:element.options.paddingBottom+'px',
                    paddingLeft:element.options.paddingLeft+'px',
                    paddingRight:element.options.paddingRight+'px',
                    backgroundImage:`url(${element.options.imageUrl})`,
                    backgroundColor:'#ffffff',
                    backgroundSize:'cover'}"
                    @click.native="handleSelectWidget(index)">
                    <el-col
                      v-for="(col, colIndex) in element.columns"
                      :key="colIndex"
                      :span="col.span ? col.span : 0">
                      <div style="border: 1px dashed #999;">
                        <draggable
                          v-if="element.componentType != 'tab-menu'"
                          class="widget-form-list"
                          style="padding-bottom: 50px;"
                          v-model="col.list"
                          filter="widget-grid-container"
                          v-bind="{group:'ug', ghostClass: 'ghost',sort:false}"
                          @end="handleMoveEnd"
                          @add="handleWidgetColAdd($event, element, colIndex)">
                          <phone-form-item
                            v-for="(el, i) in col.list"
                            :key="i"
                            :element="el"
                            :select.sync="selectWidget"
                            :index="i"
                            :data="col"
                            :close.sync="isClose"
                          ></phone-form-item>
                        </draggable>
                        <!--是tab-menus类型的 里面内容不可以删除和拖动-->
                        <template v-else>
                          <div class="widget-form-list"
                               style="padding-bottom: 50px;">
                            <phone-form-item
                              v-for="(el, i) in col.list"
                              :key="i"
                              :element="el"
                              :select.sync="selectWidget"
                              :index="i"
                              :ele-type="element.componentType"
                              :data="col"
                              @click.native="changeTab(i,colIndex,index)"
                              :close.sync="isClose"></phone-form-item>
                          </div>
                        </template>
                      </div>
                    </el-col>
                  </el-row>
                  <template v-if="element.componentType != 'tab-grid'">
                    <el-button
                      title="删除"
                      style="bottom: -20px;"
                      @click.stop="handleWidgetDelete(index,element.key)"
                      class="widget-action-delete"
                      v-if="(selectWidget && selectWidget.key) == element.key"
                      circle
                      plain
                      type="danger">
                      <i class="iconfont iconshanchu" style="width: 12px;height: 12px;"></i>
                    </el-button>
                  </template>
                </div>
              </template>
              <template v-else>
                <phone-form-item
                  v-if="element"
                  :label-width="element.options.isLabel ? widgetData.config.labelWidth + 'px':'0px'"
                  :key="index"
                  :element="element"
                  :select.sync="selectWidget"
                  :index="index"
                  @click.native="changeTabItem"
                  :data="widgetData"
                  :frame="frame"
                  :close.sync="isClose">
                </phone-form-item>
              </template>
            </template>
          </draggable>
        </el-form>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import Draggable from 'vuedraggable'
  import PhoneFormItem from './PhoneFormItem'
  import {gridColumns} from './gridTypeConfig'
  import '../../styles/phone.less'

  import {
    phoneTypeList,
    phoneScaleList
  } from './phoneTypeConfig'
  export default {
    components: {
      Draggable,
      PhoneFormItem
    },
    props: ['data', 'select', 'frame', 'close'],
    data() {
      return {
        phoneTypeList,
        phoneScaleList,
        selectWidget: this.select,
        widgetData: this.data,
        phoneType: '',
        phoneScale: '',
        phoneTypeClass: {},
        phoneTypeBgClass: {},
        phoneScaleStyle: {
          'transformOrigin': '50% 0%'
        },
        isClose: this.close
      }
    },
    created() {
      this.phoneType = this.phoneTypeList[0]
      this.selectPhone()
    },
    methods: {
      handleMoveEnd({newIndex, oldIndex}) {
        // this.putRightPos(newIndex)
        // console.log("index", newIndex, oldIndex);
      },
      handleSelectWidget(index) {
        console.log(999999)
        this.selectWidget = this.widgetData.list[index]
        this.isClose = false
      },
      // 增加外层楼层
      handleWidgetAdd(evt) {
        console.log('啦啦啦 --- > ？ > ')
        const newIndex = evt.newIndex
        // copy
        this.widgetData = JSON.parse(JSON.stringify(this.widgetData))
        const key =
          Date.parse(new Date()) + '_' + Math.ceil(Math.random() * 99999)
        console.log(this.widgetData.list)
        this.$set(this.widgetData.list, newIndex, {
          ...this.widgetData.list[newIndex],
          key,
          // 绑定键值
          model: this.widgetData.list[newIndex].type + '_' + key,
          rules: []
        })
        if (
          this.widgetData.list[newIndex].type === 'radio' ||
          this.widgetData.list[newIndex].type === 'checkbox'
        ) {
          this.$set(this.widgetData.list, newIndex, {
            ...this.widgetData.list[newIndex],
            options: {
              ...this.widgetData.list[newIndex].options,
              options: this.widgetData.list[newIndex].options.options.map(item => ({
                ...item
              }))
            }
          })
        }
        /**
         * 如果是栅格或表单，重新为list的每一项生成key和model的随机数
         */
        if (this.widgetData.list[newIndex].type === 'grid') {
          // columns: this.widgetData.list[newIndex].columns.map({...item})
          this.$set(this.widgetData.list, newIndex, {
            ...this.widgetData.list[newIndex],
            columns: this.widgetData.list[newIndex].columns.map(item => {
              item.list.forEach(element => {
                let temp = Date.parse(new Date()) + '_' + Math.ceil(Math.random() * 99999)
                element.key = temp
                element.model = element.componentType + '_' + temp
                // data
                if (element.options.component.dataParams) {
                  let returnObj = {}
                  for (let item in element.options.component.dataParams) {
                    returnObj[item] = element.options.component.dataParams[item]
                  }
                  element.options.component.data = function () {
                    return returnObj
                  }
                }
                // methods
                if (element.options.component.methodParams) {
                  element.options.component.methods = {
                    [element.options.component.methodParams.methodName]() {
                      // eslint-disable-next-line
                      eval(element.options.component.methodParams.methodValue)
                    }
                  }
                }
              })
              return {...item}
            })
          })
        }
        this.putRightPos(newIndex)
        // if (this.widgetData.list[newIndex].componentType === 'tab-menu') {
        //   let itemData = {
        //     colCont: this.widgetData.list[newIndex].columns,
        //     fatKey: this.widgetData.list[newIndex].key,
        //     num: this.widgetData.list[newIndex].tabsSet.columns
        //   }
        //   this.tabItemSet(newIndex, itemData, this.widgetData.list[newIndex])
        // }
        // this.selectWidget = this.widgetData.list[newIndex]
      },
      putRightPos(newIndex) {
        console.log('显示正确的位置 》》 ')
        // 判断是不是放置在 componentType 类型为tab-menu 和 tab-grid之间 是直接放置到 tab-grid 后面
        if (this.widgetData.list[newIndex - 1] && this.widgetData.list[newIndex + 1]) {
          console.log('我在中间呀！！！')
          // 放到后面显示
          // 判断拖拽的是不是 标签页组件
          if (this.widgetData.list[newIndex].componentType === 'tab-menu') {
            this.widgetData.list.push(this.widgetData.list.splice(newIndex, 1)[0])
            let len = this.widgetData.list.length - 1
            let itemData = {
              colCont: this.widgetData.list[len].columns,
              fatKey: this.widgetData.list[len].key,
              num: this.widgetData.list[len].tabsSet.columns
            }
            this.tabItemSet(len, itemData, this.widgetData.list[len])
          } else {
            this.widgetData.list.splice(newIndex, 1)
          }
          this.selectWidget = this.widgetData.list[this.widgetData.list.length - 2]
        } else {
          if (this.widgetData.list[newIndex].componentType === 'tab-menu') {
            let itemData = {
              colCont: this.widgetData.list[newIndex].columns,
              fatKey: this.widgetData.list[newIndex].key,
              num: this.widgetData.list[newIndex].tabsSet.columns
            }
            this.tabItemSet(newIndex, itemData, this.widgetData.list[newIndex])
            this.selectWidget = this.widgetData.list[newIndex]
          } else {
            if (this.widgetData.list[newIndex + 1]) {
              this.selectWidget = this.widgetData.list[newIndex + 1]
            } else if (this.widgetData.list[newIndex - 1]) {
              this.selectWidget = this.widgetData.list[newIndex - 2]
            } else {
              this.selectWidget = {}
            }
            // 最外层 删除不是组件类型不是 tab-menu的元素
            setTimeout(() => { this.widgetData.list.splice(newIndex, 1) })
            // this.widgetData.list.splice(newIndex, 1)
          }
        }
      },
      // 增加栅格内层列选项的布局
      handleWidgetColAdd($event, row, colIndex) {
        console.log('增加列 》》》 ')
        const newIndex = $event.newIndex
        const oldIndex = $event.oldIndex
        const item = $event.item
        // 防止布局元素的嵌套拖拽
        if (item.className.indexOf('data-grid') >= 0) {
          console.log(1222222)
          // 如果是列表中拖拽的元素需要还原到原来位置
          item.tagName === 'DIV' &&
            this.widgetData.list.splice(oldIndex, 0, row.columns[colIndex].list[newIndex])
          row.columns[colIndex].list.splice(newIndex, 1)
          return false
        }
        const key =
          Date.parse(new Date()) + '_' + Math.ceil(Math.random() * 99999)
        console.log('key >>>>> ', key)
        this.$set(row.columns[colIndex].list, newIndex, {
          ...row.columns[colIndex].list[newIndex],
          options: {
            ...row.columns[colIndex].list[newIndex].options,
            remoteFunc: 'func_' + key
          },
          key,
          // 绑定键值
          model: row.columns[colIndex].list[newIndex].type + '_' + key,
          rules: []
        })

        if (
          row.columns[colIndex].list[newIndex].type === 'radio' ||
          row.columns[colIndex].list[newIndex].type === 'checkbox' ||
          row.columns[colIndex].list[newIndex].type === 'actionSheet' ||
          row.columns[colIndex].list[newIndex].type === 'card' ||
          row.columns[colIndex].list[newIndex].type === 'selector'
        ) {
          this.$set(row.columns[colIndex].list, newIndex, {
            ...row.columns[colIndex].list[newIndex],
            options: {
              ...row.columns[colIndex].list[newIndex].options,
              options: row.columns[colIndex].list[newIndex].options.options.map(
                item => ({
                  ...item
                })
              )
            }
          })
        }

        this.selectWidget = row.columns[colIndex].list[newIndex]
      },
      handleWidgetDelete(index, key) {
        console.log('选择删除！！！')
        // 点击最后一个
        if (this.widgetData.list.length - 1 === index) {
          if (index === 0) {
            this.selectWidget = {}
          } else {
            // 判断上一个元素的组件类型是不是 tab-grid
            if (this.widgetData.list[index - 1].componentType === 'tab-grid') {
              this.selectWidget = this.widgetData.list[index - 2]
            } else {
              this.selectWidget = this.widgetData.list[index - 1]
            }
          }
        } else { // 不是点击最后一个的时候
          // 判断下一个元素的组件类型是不是 tab-grid
          if (this.widgetData.list[index + 1].componentType === 'tab-grid') {
            if (this.widgetData.list[index + 2]) {
              this.selectWidget = this.widgetData.list[index + 2]
            } else {
              if (this.widgetData.list[index - 1]) {
                // 没有元素的话聚焦到上一个元素
                if (this.widgetData.list[index - 1].componentType === 'tab-grid') {
                  this.selectWidget = this.widgetData.list[index - 2]
                } else {
                  this.selectWidget = this.widgetData.list[index - 1]
                }
              } else {
                this.selectWidget = {}
              }
            }
          } else {
            this.selectWidget = this.widgetData.list[index + 1]
          }
        }
        this.$nextTick(() => {
          if (this.widgetData.list[index].componentType === 'tab-menu') {
            this.widgetData.list.splice(index, 2)
            // 每次删除标签页的元素 就直接删除对应的 子元素集合
            delete this.$ug.globalData[key]
            console.log('globalData >> ', this.$ug.globalData)
          } else {
            this.widgetData.list.splice(index, 1)
          }
        })
      },
      // 选择手机型号
      selectPhone() {
        for (let item of this.phoneTypeList) {
          // 添加class样式
          this.phoneTypeClass[item.value] = (this.phoneType.value === item.value)
          this.phoneTypeBgClass[item.classBg] = (this.phoneType.value === item.value)
          // 根据手机型号选择最佳缩放比
          if (this.phoneType.value === item.value) {
            this.phoneScale = this.phoneScaleList.filter((scale) => {
              return scale.value === item.adjustZoom
            })[0]
          }
        }
        this.selectScale()
      },
      // 选择规格
      selectScale() {
        for (let item of this.phoneScaleList) {
          if (this.phoneScale.value === item.value) {
            this.phoneScaleStyle.transform = item.transform
          }
        }
        let adjust = this.phoneScaleList.filter((scale) => {
          return scale.value === this.phoneType.adjustZoom
        })[0]
        let preview = {
          'phoneTypeClass': this.phoneTypeClass,
          'phoneTypeBgClass': this.phoneTypeBgClass,
          'phoneScaleStyle': {
            'transformOrigin': '50% 0%',
            'transform': adjust.transform
          },
          'phoneFrame': this.frame
        }
        this.$emit('phonePreview', preview)
      },
      /**
       * 当最外层type='grid'时 列数组里面每个具体元素的点击事件
       * 场景（点击某一列内容时 切换下面的内容)
       * @param curIndex 当前目标元素
       * @param colIndex 列元素下标
       * @param outIndex 最外层元素下标
       */
      changeTab(curIndex, colIndex, outIndex) {
        console.log(12356789)
        console.log('curIndex >> ', curIndex)
        console.log('colIndex >> ', colIndex)
        console.log('outIndex >> ', outIndex)
        if (this.widgetData.list[outIndex].componentType === 'tab-menu') {
          // 切换组件数据
          this.$set(this.widgetData.list, outIndex + 1, this.$ug.globalData[this.widgetData.list[outIndex].key][colIndex])
        }
      },
      changeTabItem() {},
      tabItemSet(newIndex, itemData, tab) {
        this.$ug.globalData[itemData.fatKey] = gridColumns(itemData.colCont, itemData.fatKey, itemData.num)
        this.widgetData.list.splice(newIndex + 1, 0, this.$ug.globalData[itemData.fatKey][0])
        // 遍历显示将值显示塞到child 数组里面
        for (let i = 0, len = tab.columns.length; i < len; i++) {
          tab.columns[i].child = this.$ug.globalData[itemData.fatKey][i]
        }
        console.log('this.$ug.globalData >> ', this.$ug.globalData)
      },
      checkMove(evt) {
        console.log('evt >> ', evt)
        console.log('我在移动呀！！！')
      }
    },
    watch: {
      select(val) {
        this.selectWidget = val
      },
      selectWidget: {
        handler(val) {
          this.$emit('update:select', val)
        },
        deep: true
      },
      close(val) {
        this.isClose = val
      },
      isClose: {
        handler(val) {
          this.$emit('update:close', val)
        },
        deep: true
      },
      data: {
        handler(val) {
          this.widgetData = val
        },
        deep: true
      },
      widgetData: {
        handler(val) {
          console.log('val --- >', val)
          this.$emit('update:data', val)
        },
        deep: true
      }
    }
  }
</script>
<style lang="less" scoped>
  .phone-form{
    position: absolute;
    top: 5px;
    left: 0;
    right: 0;
    bottom: 0;
  }
  .phoneType{
    width: 100%;
    height: 30px;
    margin-bottom: 20px;
    .pixel{
      width: 80%;
      height: 28px;
      line-height: 28px;
      text-align: center;
      margin: 0px auto;
      font-size: 14px;
      border: 1px dashed #dedede;
    }
  }
</style>

export const phoneTypeList = [
  {
    value: 'iphone6s',
    label: 'iphone 6/7/8s',
    pixel: '375 X 667',
    classBg: 'phone-6s-bg',
    adjustZoom: 'sc70'
  }, {
    value: 'iphoneX',
    label: 'iphone X',
    pixel: '375 X 812',
    classBg: 'phone-X-bg',
    adjustZoom: 'sc65'
  }, {
    value: 'oppoR17',
    label: '华为畅享 9S',
    pixel: '360 X 640',
    classBg: 'phone-oppoR17-bg',
    adjustZoom: 'sc75'
  }, {
    value: 'xiaomiMIX3',
    label: '小米MIX3',
    pixel: '360 X 780',
    classBg: 'phone-xiaomiMIX3-bg',
    adjustZoom: 'sc65'
  }, {
    value: 'samsungGalaxyNote9',
    label: 'Samsung Galaxy Note 9',
    pixel: '480 x 853',
    classBg: 'phone-samsungGalaxyNote9-bg',
    adjustZoom: 'sc60'
  }, {
    value: 'huaweiMatePro20',
    label: '华为 mate Pro 20',
    pixel: '480 x 853',
    classBg: 'phone-huaweiMatePro20-bg',
    adjustZoom: 'sc60'
  }]

export const phoneScaleList = [
  {
    value: 'sc60',
    label: '60%',
    transform: 'scale(.6)'
  }, {
    value: 'sc65',
    label: '65%',
    transform: 'scale(.65)'
  },
  {
    value: 'sc70',
    label: '70%',
    transform: 'scale(.7)'
  },
  {
    value: 'sc75',
    label: '75%',
    transform: 'scale(.75)'
  }, {
    value: 'sc90',
    label: '90%',
    transform: 'scale(.9)'
  }, {
    value: 'sc100',
    label: '100%',
    transform: 'scale(1)'
  }, {
    value: 'sc125',
    label: '125%',
    transform: 'scale(1.25)'
  }
]

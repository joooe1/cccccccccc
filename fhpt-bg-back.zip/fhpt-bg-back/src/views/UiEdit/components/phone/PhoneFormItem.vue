<template>
  <el-form-item class="widget-view "
                v-if="element"
                :class="{active: (selectWidget && selectWidget.key) == (element.key && element.key), 'is_req': element.options.required}"
                :label="element.options.showLabel ? element.name:''"
                @click.native.stop="handleSelectWidget(index)">
    <!--dynamic loading selected component -->
    <component :is="this.element.options.component" :element="element" style="zoom:.6" @click.native="changeTab">
    </component>
    <template v-if="eleType != 'tab-menu'">
      <el-button title="删除" @click.stop="handleWidgetDelete(index)"
                 class="widget-action-delete"
                 v-if="(selectWidget && selectWidget.key) == (element.key && element.key)"
                 circle plain type="danger">
        <i class="iconfont iconshanchu" style="width: 12px;height: 12px;"></i>
      </el-button>
      <el-button title="复制" @click.stop="handleWidgetClone(index)"
                 class="widget-action-clone"
                 v-if="(selectWidget && selectWidget.key) == (element.key && element.key)"
                 circle plain type="primary">
        <i class="iconfont iconfuzhi" style="width: 12px;height: 12px;"></i>
      </el-button>
    </template>
  </el-form-item>
</template>

<script>
  export default {
    props: ['element', 'select', 'index', 'data', 'frame', 'close', 'eleType'],
    data() {
      return {
        selectWidget: this.select,
        isClose: this.close
      }
    },
    created() {},
    methods: {
      handleSelectWidget(index) {
        this.selectWidget = this.data.list[index]
        this.isClose = false
      },
      handleWidgetDelete(index) {
        // if (this.data.list.length - 1 === index) {
        //   if (index === 0) {
        //     this.selectWidget = {}
        //   } else {
        //     this.selectWidget = this.data.list[index - 1]
        //   }
        // } else {
        //   this.selectWidget = this.data.list[index + 1]
        // }
        // this.$nextTick(() => {
        //   this.data.list.splice(index, 1)
        // })
        if (this.data.list.length - 1 === index) {
          if (index === 0) {
            this.selectWidget = {}
          } else {
            // 判断上一个元素的组件类型是不是 tab-grid
            if (this.data.list[index - 1].componentType === 'tab-grid') {
              this.selectWidget = this.data.list[index - 2]
            } else {
              this.selectWidget = this.data.list[index - 1]
            }
          }
        } else { // 不是点击最后一个的时候
          this.selectWidget = this.data.list[index + 1]
        }
        this.$nextTick(() => {
          if (this.data.list[index].componentType === 'tab-menu') {
            this.data.list.splice(index, 2)
          } else {
            this.data.list.splice(index, 1)
          }
        })
      },
      handleWidgetClone(index) {
        let cloneData = {
          ...this.data.list[index],
          options: {...this.data.list[index].options},
          key: Date.parse(new Date()) + '_' + Math.ceil(Math.random() * 99999)
        }
        if (this.data.list[index].type === 'radio' || this.data.list[index].type === 'checkbox') {
          cloneData = {
            ...cloneData,
            options: {
              ...cloneData.options,
              options: cloneData.options.options.map(item => ({...item}))
            }
          }
        }
        this.data.list.splice(index, 0, cloneData)
        this.$nextTick(() => {
          this.selectWidget = this.data.list[index + 1]
        })
      }
    },
    watch: {
      select(val) {
        this.selectWidget = val
      },
      selectWidget: {
        handler(val) {
          this.$emit('update:select', val)
        },
        deep: true
      },
      close(val) {
        this.isClose = val
      },
      isClose: {
        handler(val) {
          this.$emit('update:close', val)
        },
        deep: true
      }
    }
  }
</script>

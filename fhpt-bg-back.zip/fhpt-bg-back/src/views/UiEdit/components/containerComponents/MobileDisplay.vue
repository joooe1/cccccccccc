<template>
  <el-container>
    <el-header class="menu-header" style="height: 45px">
      <div
        class="menu-tab"
        :class="{'active':type === 0}"
        @click="handleClick(0)"
      >基础组件
      </div>
      <div
        class="menu-tab"
        :class="{'active':type === 1}"
        @click="handleClick(1)"
      >业务组件
      </div>
    </el-header>
    <el-main>
      <template v-if="type=='0'">
        <div class="components-list" v-for="(basic,basicIndex) in data.basic" :key="basicIndex">
          <div class="widget-cate">{{basic.name}}</div>
          <draggable
            tag="ul"
            :list="basic.value"
            v-bind="{group:{ name:'ug', pull:'clone',put:false},sort:false, ghostClass: 'ghost'}">
            <!--暂时不展示轮播组件，移至业务组件中，当远程服务器支持图片存储后放开该限制-->
            <li
              class="form-edit-widget-label"
              v-for="(item, index) in basic.value"
              :key="index">
              <a>
                <icon class="icon" :name="item.icon"></icon>
                <span>{{item.name}}</span>
              </a>
            </li>
          </draggable>
        </div>
      </template>
      <template v-else>
        <div class="components-list" v-for="(business,businessIndex) in data.business" :key="businessIndex">
          <!--<div class="widget-cate">{{business.name}}</div>-->
          <draggable
            tag="ul"
            :list="business.value"
            v-bind="{group:{ name:'ug', pull:'clone',put:false},sort:false, ghostClass: 'ghost'}"
          >
            <li
              class="form-edit-widget-label"
              v-for="(item, index) in business.value"
              :key="index"
            >
              <a>
                <icon class="icon" :name="item.icon"></icon>
                <span>{{item.name}}</span>
              </a>
            </li>
          </draggable>
        </div>
      </template>
    </el-main>
  </el-container>
</template>

<script>
  import Draggable from 'vuedraggable'

  export default {
    name: 'container-mobile-display',
    components: {
      Draggable
    },
    props: {
      data: {
        type: Object
      }
    },
    data() {
      return {
        type: 0
      }
    },
    methods: {
      handleClick(type) {
        this.type = type
      }
    }
  }
</script>

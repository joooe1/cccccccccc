<!--将拖拽代码转化为json格式-->
<template>
  <cus-dialog
    :visible="visibleTemp"
    @on-close="handleClose"
    width="800px"
    form>
    <div id="jsoneditor" style="height: 400px;width: 100%;">{{json}}</div>
  </cus-dialog>
</template>

<script>
  import CusDialog from '../../CusDialog'
  export default {
    name: 'cus-dialog-code-json',
    components: {
      CusDialog
    },
    props: {
      visible: {
        type: Boolean,
        default: false
      },
      json: {
        type: Object
      }
    },
    data() {
      return {
        visibleTemp: this.visible
      }
    },
    methods: {
      handleClose() {
        this.visibleTemp = false
        this.$emit('update:visible', this.visibleTemp)
      },
      doubleClick() {
        // const btnCopy = new Clipboard('#copybtn')
        // btnCopy.on('success', (e) => {
        //   this.$message({
        //     message: '已成功复制到剪切板',
        //     type: 'success'
        //   })
        //   e.clearSelection()
        // })
      }
    },
    watch: {
      visible(val) {
        this.visibleTemp = val
      }
    }
  }
</script>

<style scoped></style>

<!--预览-->
<template>
  <cus-dialog
    :visible="visibleTemp"
    @on-close="handleClose"
    :terminal="modeType"
    ref="handlePreview"
    width="1000px"
    form>
    <phone-generate-form v-if="modeType=='mobile'"
      :data="options.mobile.data"
      :remote="options.mobile.remote"
      :value="options.mobile.value"
      :preview="options.mobile.preview">
    </phone-generate-form>
  </cus-dialog>
</template>

<script>
  import CusDialog from '../../CusDialog'
  import PhoneGenerateForm from '../../phone/PhoneGenerateForm'

  export default {
    name: 'cus-dialog-preview',
    components: {
      CusDialog,
      PhoneGenerateForm
    },
    props: {
      modeType: {
        type: String,
        default: 'mobile'
      },
      visible: {
        type: Boolean,
        default: false
      },
      options: {
        type: Object
      }
    },
    created() {
      console.log('options >>> ', this.options)
    },
    data() {
      return {
        visibleTemp: this.visible
      }
    },
    methods: {
      handleClose() {
        this.visibleTemp = false
        this.$emit('update:visible', this.visibleTemp)
      }
    },
    watch: {
      visible(val) {
        this.visibleTemp = val
      }
    }
  }
</script>

<style scoped>

</style>

<template>
  <div class="float-window full-height bg-white">
    右侧浮动框
  </div>
</template>
<script type="text/ecmascript-6">
  export default {
    name: 'attribute-setting',
    components: {},
    data() {
      return {}
    },
    created() {},
    mounted() {
    },
    computed: {},
    methods: {},
    beforeDestroy() {
    }
  }
</script>

<style type="text/css" lang="less" scoped>
  .float-window{}
</style>

<template>
  <div class="bg-white cover-all" style="border-left: 1px solid #ddd">
    <div class="menu-header" style="height: 45px">
      <div class="menu-tab" :class="{'active':type === 0}" @click="handleClick(0)">功能组件</div>
    </div>
    <div style="overflow: auto;height: calc(100% - 45px)">
      <template>
        <div class="components-list" v-for="(basic,basicIndex) in data.basic" :key="basicIndex">
          <div class="widget-cate t-left m-l10">{{basic.name}}</div>
          <draggable tag="ul" :list="basic.value"
                     v-bind="{group:{ name:'ug', pull:'clone',put:false},sort:false, ghostClass: 'ghost'}">
            <li class="form-edit-widget-label"
                v-for="(item, index) in basic.value"
                :key="index">
              <a>
                <span>{{item.name}}</span>
              </a>
            </li>
          </draggable>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
  import Draggable from 'vuedraggable'

  export default {
    name: 'container-mobile-display',
    components: {
      Draggable
    },
    props: {
      data: {
        type: Object
      }
    },
    created() {
    },
    data() {
      return {
        type: 0
      }
    },
    methods: {
      handleClick(type) {
        this.type = type
      }
    }
  }
</script>

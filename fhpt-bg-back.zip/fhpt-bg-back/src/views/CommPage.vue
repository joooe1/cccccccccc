<template>
  <div class="comm-page cover-all">
    <top-nav></top-nav>
    <div class="content re ov-hidden">
      <aside-menu class="fl" ref="aside" :class="['aside-menu',{'aside-shrink':asideWidthShrink}]"></aside-menu>
      <div class="t-center ov-hidden" style="height: 100%;background: #f4f4f4">
        <router-view class="cover-all"/>
      </div>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  import {AsideMenu, TopNav} from '@lcomp'
  export default {
    name: 'CommPage',
    components: {
      AsideMenu,
      TopNav
    },
    data() {
      return {
        asideWidthShrink: false
      }
    },
    created() {
    },
    mounted() {
    },
    computed: {},
    methods: {},
    beforeDestroy() {}
  }
</script>

<style type="text/css" lang="less" scoped>
  .content {
    height: calc(100% - 60px);
    width: 100%;
  }
  .aside-menu{
    height: 100%;
    width: 200px;
  }
  .aside-shrink{
    width: 65px !important;
  }
</style>

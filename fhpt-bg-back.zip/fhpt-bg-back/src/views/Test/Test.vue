<template>
  <div>
    我是测试页面
    <draggable element="ul" v-model="list" v-bind="{group:'ug', ghostClass: 'ghost'}">
      <li v-for="(item, index) in list" :key='index'>{{item.name}}</li>
    </draggable>
    {{list}}
    <p class="m-t20">下面点击按钮</p>
    <div @click="addData">点我添加数据</div>
  </div>
</template>
<script type="text/ecmascript-6">
  import Draggable from 'vuedraggable'
  export default {
    name: 'Test',
    components: {
      Draggable
    },
    data() {
      return {
        list: [
          {
            id: 1,
            name: 'a'
          },
          {
            id: 2,
            name: 'b'
          },
          {
            id: 3,
            name: 'c'
          },
          {
            id: 4,
            name: 'd'
          },
          {
            id: 5,
            name: 'e'
          },
          {
            id: 6,
            name: 'f'
          }
        ]
      }
    },
    created() {
    },
    mounted() {
    },
    computed: {},
    methods: {
      addData() {
        this.list.push({
          id: 55,
          name: '444a'
        })
      }
    },
    beforeDestroy() {
    }
  }
</script>

<style type="text/css" lang="less" scoped>

</style>

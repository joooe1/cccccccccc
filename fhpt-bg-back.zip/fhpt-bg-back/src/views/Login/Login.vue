<template>
  <div class="login cover-all">
    <div>
      我是登录页面
    </div>
    <el-button @click="$router.push('/')">
      返回首页
    </el-button>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    created() {
      console.log(this.$ug.ugParams().name)
    }
  }
</script>

<style type="text/css" lang="less" scoped>
  .login {
    background: url("../../../public/static/images/loginBg.png");
    background-size: 100% 100%;
  }
</style>

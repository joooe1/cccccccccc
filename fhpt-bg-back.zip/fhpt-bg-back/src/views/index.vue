<template>
  <div class="home">
    <div style="font-size: 20px">
      <div style="font-size: 1em">首页显示</div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'home',
    created() {},
    methods: {},
    components: {}
  };
</script>

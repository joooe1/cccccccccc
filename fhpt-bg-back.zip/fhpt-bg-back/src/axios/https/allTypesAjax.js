/**
 * Created by Jarek
 * 全局常用交易请求
 */
import axios from 'axios'
import qs from 'qs'

let _instance
// 初始化默认选项配置
const options = {
  timeout: 300000,
  withCredentials: false,
  headers: {
    Accept: 'application/json, text/plain, */*',
    'Content-Type': 'application/json;charset=utf-8'
  }
}
_instance = axios.create(options)
_instance.interceptors.request.use(
  config => {
    let isFormData = config.isFormData
    delete config.isFormData
    if (!isFormData) {
      if (config.method === 'post' || config.method === 'put' || config.method === 'patch') {
        // 传参json给后台(只有是post、put、patch请求方式时)
        config.data = JSON.stringify(config.data)
        return config
      }
    }
    // qs.stringify()将对象 序列化成URL的形式，以&进行拼接
    // FormData 时候传值是 a=张三&v=12样式
    config.data = qs.stringify(config.data, {allowDots: true, indices: false})
    return config
  }, error => {
    return Promise.reject(error)
  }
)
_instance.interceptors.response.use(
  response => {
    //   1.判空
    if (response.data === '' || response.data.length === 0 || response.data === 'undefined' || response.data === undefined) {
      // console.log('后台传来的data为空/为undefined')
    }
    return response
  }, error => {
    return Promise.reject(error)
  }
)
export default {
  /**
   * 封装ajax 发交易（任意类型）
   * @param url 请求的路径
   * @param method 请求的方式 默认post
   * @param params 请求的参数
   * @param showLoading 是否显示 loading  true：显示 false：不显示
   * @param needHandlerErr 是否公共拦截报错 true 公共拦截 false 自行定义报错
   * @param isFormData 是否是form key-value 传参的方式 默认上传字符串
   * @param options 请求的头的其它配置 eg：headers: {'Content-Type': 'application/json;charset=utf-8'}
   * @returns {Promise<any>}
   */
  ajaxMixin(url, {method = 'post', params = {}, showLoading = true, needHandlerErr = true, isFormData = false} = {}, options = {}) {
    let _this = this
    // 是 FormData 时候 设置头部Content-Type为FormData类型
    isFormData && Object.assign(options.headers, {'Content-Type': 'application/x-www-form-urlencoded'})
    // 将get、delete、head的数据起来合并到options里
    // 将post、put、patch的数据起来合并到options里
    Object.assign(options, {isFormData})
    return new Promise((resolve, reject) => {
      showLoading && _this.ugLoading()
      // 判读是不是get delete head 类型 只有两个参数（url,[,config]）
      // 否则 post、put、patch三个参数(url,[,data[,config]])
      if ('getdeletehead'.includes(method)) {
        // 改变默认请求文本类型
        // Object.assign(options.headers, { 'Content-Type': '' })
        // 如果为get delete head 类型 将所有的参数合并到第二个参数 params
        params = Object.assign({}, {params}, options)
      }
      _instance[method](url, params, options).then(res => {
        let {data} = res
        if (!(data.status === '000000')) {
          if (needHandlerErr) {
            showLoading && _this.ugHideLoading()
            if (data.msg) {
              _this.ugAlert(data.msg, {title: '错误提示'})
            } else {
              _this.ugAlert(`未解析到服务器端错误,错误码：【${data.status}】`, {title: '错误提示'})
            }
            return reject(data)
          }
          reject(data)
        } else {
          showLoading && _this.ugHideLoading()
          resolve(data)
        }
      }).catch(err => {
        // 细化错误消息
        if (err && err.response) {
          showLoading && _this.ugHideLoading()
          const errMsg = err.message
          if (errMsg.includes('Network Error')) {
            _this.ugAlert('网络异常，请稍后尝试', {title: '错误提示'})
          } else if (errMsg.includes('timeout')) {
            _this.ugAlert('请求超时，请稍后尝试', {title: '错误提示'})
          } else {
            let errmsg
            switch (err.response.status) {
              case 400:
                errmsg = '请求错误'
                break
              case 401:
                errmsg = '未授权，请登录'
                break
              case 403:
                errmsg = '拒绝访问'
                break
              case 404:
                let errTransCode = err.response.config.url.slice(err.response.config.url.lastIndexOf('/') + 1)
                errmsg = `404 找不到请求的资源: ${errTransCode}`
                break
              case 408:
                errmsg = '请求超时'
                break
              case 500:
                errmsg = `500 服务器内部错误 [${errMsg}]`
                break
              case 501:
                errmsg = '服务未实现'
                break
              case 502:
                errmsg = '网关错误'
                break
              case 503:
                errmsg = '服务不可用'
                break
              case 504:
                errmsg = '网关超时'
                break
              case 505:
                errmsg = 'HTTP版本不受支持'
                break
              default:
                errmsg = `请求出错 [${errMsg}]`
                break
            }
            _this.ugAlert(errmsg, {title: '错误提示'})
          }
        }
        // reject(err)
      }).finally(
        // 关闭loading 加载遮罩
        // _this.ugHideLoading()
      )
    })
  }
}

/**
 * Created by Jarek
 * 全局常用工具函数模块
 */
import Vue from 'vue'
import router from '@/router'
import store from '@/store'

let VM = new Vue()
export default {
  // 公用确认对话框
  ugConfirm(content = '确认消息!', {
    confirmButtonText = '确认',
    cancelButtonText = '取消',
    confirmButtonClass = '',
    cancelButtonClass = '',
    title = '温馨提示',
    confirmCallback,
    cancelCallback
  } = {}) {
    VM.$confirm(content, title, {
      confirmButtonText: confirmButtonText,
      cancelButtonText: cancelButtonText,
      cancelButtonClass: `${cancelButtonClass}`,
      confirmButtonClass: `${confirmButtonClass}`,
      center: true,
      showClose: false,
      closeOnClickModal: false
    }).then(() => {
      if (typeof confirmCallback === 'function') {
        confirmCallback()
      }
    }).catch(() => {
      if (typeof cancelCallback === 'function') {
        cancelCallback()
      }
    })
  },
  // 公用对话框
  ugAlert(content = '请输入提示内容', {title = '温馨提示', confirmButtonText = '确定', calFun} = {}) {
    VM.$alert(content, title, {
      confirmButtonText: confirmButtonText,
      center: true,
      showClose: false,
      callback: action => {
        if (typeof calFun === 'function') {
          calFun()
        }
      }
    })
  },
  // 加载转圈
  ugLoading(text = 'loading') {
    VM.$loading({
      lock: true,
      text: text,
      spinner: 'el-icon-loading',
      background: 'rgba(255, 255, 255, 0.7)'
    })
  },
  // 关闭加载转圈
  ugHideLoading(text = 'loading') {
    VM.$loading({
      lock: true,
      text: text,
      spinner: 'el-icon-loading',
      background: 'rgba(255, 255, 255, 0.7)'
    }).close()
  },
  /**
   * 公共界面路由 跳转
   * @param path 路由地址 -1 routePath
   * @param params 跳转的路由所带的参数
   * @param clearParamsStack 界面导航的时候，是否清空参数栈，默认为true(参数栈只保留最新一版参数)
   * @param type 编程式导航类型 push replace go
   */
  ugNextPage(path, {params = {}, clearParamsStack = true} = {}, type = 'push') {
    let isEmptyObj = JSON.stringify(params) === '{}'
    // 默认只保留最近一次参数
    if (!isEmptyObj && clearParamsStack) {
      store.commit('ug/common/clearParamsStack')
      store.commit('ug/common/pushParams', params)
      //  参数栈不断累加 不清空
    } else if (!isEmptyObj && !clearParamsStack) {
      store.commit('ug/common/pushParams', params)
    }
    router[type](path)
  },
  /**
   * 获取传递的参数
   * @param paramsNum 获取第几个参数（默认取最新存储的）
   * @returns {*}
   */
  ugParams(paramsNum) {
    let paramsArr = JSON.parse(sessionStorage.getItem('__PARAMS_STACK__'))
    if (paramsArr.length > 0) {
      if (paramsNum) {
        return paramsArr[(paramsNum - 1)]
      }
      return paramsArr[paramsArr.length - 1]
    }
  },
  /**
   * 数据转换 深度拷贝 转换指针 (拿值、清除值)
   * @param data 要保存的数据
   * @param clearData 是否要清除临时值
   * @returns {*}
   */
  dataConversion(data, clearData = false) {
    if (clearData) {
      sessionStorage.removeItem('__TEMPDATA__')
    } else {
      if (sessionStorage.getItem('__TEMPDATA__')) {
        return JSON.parse(sessionStorage.getItem('__TEMPDATA__'))
      }
      this.saveSesTemp(data)
      return JSON.parse(sessionStorage.getItem('__TEMPDATA__'))
    }
  },
  /**
   * 保存临时值
   * @param data 要保存的数据
   * @returns {*}
   */
  saveSesTemp(data) {
    console.log('data >> ', data)
    sessionStorage.setItem('__TEMPDATA__', JSON.stringify(data))
  },
  /**
   * @param data 获取session存的数据
   * @returns {*}
   */
  getSesObj(key) {
    return JSON.parse(sessionStorage.getItem(key))
  },
  /**
   * @param data 要保存session的数据
   * isChageProVal : 存储为对象时 改变对象中某个属性的值
   * @returns {*}
   */
  setSesObj(key, value, value1, isChageProVal = false) {
    if (isChageProVal) {
      let obj = this.getSesObj(key)
      value in obj && (obj[value] = value1)
      sessionStorage.setItem(key, JSON.stringify(obj))
    } else {
      sessionStorage.setItem(key, JSON.stringify(value))
    }
  },
  /**
   * 四舍五入保留几位小数 不够补0
   * @param number
   * @param n 保留几位小数
   * @returns {string|number}
   */
  getFloat(number, n = 4) {
    n = n ? parseInt(n) : 0;
    if (n <= 0) {
      return Math.round(number);
    }
    number = Math.round(number * Math.pow(10, n)) / Math.pow(10, n); // 四舍五入
    number = Number(number).toFixed(n); // 补足位数
    return number;
  },
  globalData: {}
}

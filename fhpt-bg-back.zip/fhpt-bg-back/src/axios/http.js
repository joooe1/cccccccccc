// import axios from 'axios'
// import store from "../store"
// import Cookie from 'js-cookie'
// import {getItem, setItem, update} from "./IndexDB"
// import qs from 'qs'
//
// const defaultOptions = {
//     loading: true,               // 是否loading
//     cache: false,                // 是否开启本地缓存
//     cacheTime: 1000 * 60 * 10000,   // 10分钟
//     version: 1, // 版本号
//     autoAlertErr: false  // 公共拦截错误 弹框
// }
// const API = window.base_api_url || sessionStorage.getItem('base_api_url')
// const reg = new RegExp(`^${API}`, 'g')
// // 设置全局axios默认值
// axios.defaults.timeout = 30 * 1000 // 30s的超时验证
// axios.defaults.baseURL = API
// axios.defaults.withCredentials = true // 允许访问cookie
// // 发起请求之前
// axios.interceptors.request.use((config) => {
//     if (config.loading === true) {
//         store.commit('UPDATE_LOADING', { show: true })
//     }
//     if (config.method === 'POST' && config['Content-Type'] === 'application/x-www-form-urlencoded') {
//         config.data = qs.stringify(config.data)
//     }
//     config.headers['Accept'] = '*/*';
//     config.headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
//     return config
// }, (err) => {
//     console.log('全局请求错误拦截--->', err)
//     return Promise.reject(err)
// })
// //返回状态判断
// axios.interceptors.response.use((res) => {
//     const config = res.config
//     store.commit('UPDATE_LOADING', { show: false })
//     if (res.status === 200 && res.statusText === 'OK') {
//         // 这里可以做全局响应错误拦截'
//         let result = res.data
//         // 后台接口返回有code字段的 拦截到不是'0' 直接弹框报错 默认状态
//         if(result.hasOwnProperty('code') && result.code != 0 && config.autoAlertErr){
//             // 弹框报错
//             window._UG.ugAlert(result.msg)
//         }
//         // 无需验证result, null 0 false 皆为有效返回值
//         // 如果需要缓存
//         if (config.cache) {
//             const cacheData = {
//                 // data: result.data,
//                 data: result,
//                 time: new Date().getTime(),
//                 version: 1,
//                 url: config.url.replace(reg, '') // 去掉/api开头的字符
//             }
//             if (config.needUpdate === true) {
//                 update(cacheData)
//             } else {
//                 setItem(cacheData);
//             }
//         }
//         return result
//     }
// }, (error) => {
//     console.log('出错了'+error)
//     store.commit('UPDATE_LOADING', { show: false })
//     // 这里可以做全局响应错误拦截
//     // 细化错误信息
//     if (error && error.response) {
//         const errMsg = error.message
//         console.log('出错了', errMsg)
//         if (errMsg.includes('Network Error')) {
//             window._UG.ugAlert('网络异常，请稍后尝试')
//         } else if (errMsg.includes('timeout')) {
//             window._UG.ugAlert('请求超时，请稍后尝试')
//         } else {
//             let errmsg
//             switch (error.response.status) {
//                 case 400:
//                     errmsg = '请求错误'
//                     break
//                 case 401:
//                     errmsg = '未授权，请登录'
//                     break
//                 case 403:
//                     errmsg = '拒绝访问'
//                     break
//                 case 404:
//                     let errTransCode = error.response.config.url.slice(error.response.config.url.lastIndexOf('/') + 1)
//                     errmsg = `404 找不到请求的资源: ${errTransCode}`
//                     break
//                 case 408:
//                     errmsg = '请求超时'
//                     break
//                 case 500:
//                     errmsg = `500 服务器内部错误 [${errMsg}]`
//                     break
//                 case 501:
//                     errmsg = '服务未实现'
//                     break
//                 case 502:
//                     errmsg = '网关错误'
//                     break
//                 case 503:
//                     errmsg = '服务不可用'
//                     break
//                 case 504:
//                     errmsg = '网关超时'
//                     break
//                 case 505:
//                     errmsg = 'HTTP版本不受支持'
//                     break
//                 case 530:
//                     errmsg = '登录超时，请重新登录'
//                     break
//                 default:
//                     errmsg = `请求出错 [${errMsg}]`
//                     break
//             }
//             window._UG.ugAlert(errmsg)
//         }
//     }
//     return Promise.reject(error)
// })
// export default {
//     post: async (url, params = {}, options = defaultOptions) => {
//         const xToken = Cookie.get('logintoken');      //Post默认请求附带x-token
//         if(xToken && url != '/mobile/user/loginedto') {
//             params['x-session-token'] = xToken
//         }
//         const option = {...defaultOptions, ...options}
//         params = qs.stringify({...params, isVue: 1});
//         const postConfig = {
//             url,
//             data: params,
//             method: 'POST',
//             loading: option.loading,
//             // 后台接口返回有code字段的 拦截到不是'0' 直接弹框报错 默认状态
//             autoAlertErr:option.autoAlertErr
//         }
//         if (option.cache) {
//             let res = await IndexDBMiddleware(url, option)
//             if (res && res.status === 200) return Promise.resolve(res.data.data)
//             else if (res && res.status === 405) { // 数据过期
//                 return axios({...postConfig, cache: true, needUpdate: true})
//             } else {
//                 return axios({...postConfig, cache: true})
//             }
//         }
//         return axios(postConfig)
//     },
//     get: async (url, params = {}, options = defaultOptions) => {
//         const option = { ...defaultOptions, ...options }
//         const getConfig = {
//             url,
//             params,
//             method: 'GET',
//             loading: option.loading,
//             // 后台接口返回有code字段的 拦截到不是'0'直接弹框报错  默认状态
//             autoAlertErr:option.autoAlertErr
//         }
//
//         if (option.cache) {
//             let res = await IndexDBMiddleware(url, option)
//             if (res && res.status === 200) return Promise.resolve(res.data.data);
//             else if (res && res.status === 405) {
//                 return axios({...getConfig, needUpdate: true, cache: true})
//             }
//             else return axios({...getConfig, cache: true})
//         }
//         return axios(getConfig)
//     }
// }
// //浏览器数据库中间件
// async function IndexDBMiddleware(url, options) {
//     if (sessionStorage.getItem('disabledCache') === '1') {
//         return Promise.resolve({status: 500, msg: '该浏览器不支持indexDB'})
//     }
//     let result = await getItem(url)
//     return new Promise((resolve) => {
//         if (result && result.status === 200) {
//             const { data } = result
//             const now = new Date().getTime()
//             // 如果本地数据库数据版本小于线上版本 或者 超过了过期时间 抛错
//             if (data && data.data && data.version < options.version) {
//                 resolve({ status: 500, msg: '版本小于线上版本' })
//             } else if (data && data.data && now - data.time > options.cacheTime) {
//                 // deleteItem(data.url)
//                 resolve({ status: 405, msg: '数据已过期'})
//             }
//             resolve({ status: 200, data: data, msg: '获取成功' })
//         } else {
//             resolve({ status: 404, msg: '没有找到该数据' })
//         }
//     })
// }

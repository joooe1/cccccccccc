// 存入的状态
const state = {
  paramsStack: [] // 参数栈
}
// 获取状态值
const getters = {
  // 获取参数栈
  paramsStack: (state) => {
    return state.paramsStack
  }
}
// 获取行为
const actions = {}
// 更新状态（唯一）
const mutations = {
  // 设置参数入栈 始终保持三个在参数站内
  pushParams(state, params) {
    state.paramsStack.push(params)
    state.paramsStack.length > 3 && (state.paramsStack.shift())
    sessionStorage.setItem('__PARAMS_STACK__', JSON.stringify(state.paramsStack))
  },
  // 清空参数栈 手动
  clearParamsStack(state) {
    state.paramsStack = []
    sessionStorage.setItem('__PARAMS_STACK__', JSON.stringify(state.paramsStack))
  },
  // 重置到界面刚加载时的 state 状态(原始默认状态)
  resetStates(state) {
    state = Object.assign(state, JSON.parse(sessionStorage.getItem('_STORE_')))
  }
}
export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
}

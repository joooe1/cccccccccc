import Vue from 'vue'
import Vuex from 'vuex'
import ug from './modules/ug'
import createLogger from 'vuex/dist/logger'

Vue.use(Vuex)
const develop = process.env.NODE_ENV !== 'production'
export default new Vuex.Store({
  modules: {
    ug
  },
  strict: develop,
  plugins: develop ? [createLogger()] : []
})

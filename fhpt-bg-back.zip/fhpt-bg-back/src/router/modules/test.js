export default [
  {
    path: '/Test',
    name: 'Test',
    component: () => import(/* webpackChunkName: "test" */ '../../views/CommPage'),
    children: [
      {
        path: '',
        component: () => import(/* webpackChunkName: "test" */ '../../views/Test/Test')
      }
    ]
  }
]

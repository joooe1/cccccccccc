export default [
  {
    path: '/UiEdit',
    name: 'UiEdit',
    component: () => import(/* webpackChunkName: "test" */ '../../views/CommPage'),
    children: [
      {
        path: '',
        component: () => import(/* webpackChunkName: "test" */ '../../views/UiEdit/Generator')
      }
    ]
  }
]

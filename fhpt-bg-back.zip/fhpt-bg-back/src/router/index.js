import Vue from 'vue'
import Router from 'vue-router'
// import store from "@store"
import allRoutes from './routes'

Vue.use(Router)
const router = new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: allRoutes
})
// 全局路由导航守卫函数
export default router;

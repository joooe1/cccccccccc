// 整合所有的路由
const files = require.context('./modules', false, /\.js$/)
let routes = []

files.keys().forEach(key => {
    routes = [...routes, ...files(key).default]
})
// 公共路由
const globleRoutes = [
  {
    path: '/',
    name: 'index.less',
    component: () => import(/* webpackChunkName: "common" */ '../views/CommPage'),
    children: [
      {
        path: '',
        component: () => import(/* webpackChunkName: "common" */ '../views/index')
      }
    ]
  },
  {
    path: '*',
    name: '404',
    component: () => import(/* webpackChunkName: "common" */ '../views/404/404')
  },
  {
    path: '/Login',
    name: 'Login',
    component: () => import(/* webpackChunkName: "common" */ '../views/Login/Login')
  }
]
export default [
    ...globleRoutes,
    ...routes
]

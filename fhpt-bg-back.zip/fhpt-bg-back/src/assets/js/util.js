/*
* 休眠 一段时间
*/
export const sleep = async time => new Promise(resolve => setTimeout(resolve, time))
/*
*  延迟函数
*/
let debounceTimer = null
export function debounce(func, delay) {
  return function (...args) {
    if (debounceTimer) {
      clearTimeout(debounceTimer)
    }
    debounceTimer = setTimeout(() => {
      func.apply(this, args)
    }, delay)
  }
}

/*
* 创建字谜(带有重复项)
* anagrams('abc') -> ['abc','acb','bac','bca','cab','cba']
*/
export const anagrams = str => {
  if (str.length <= 2) {
    return str.length === 2 ? [str, str[1] + str[0]] : [str]
  }
  return str.split('').reduce((acc, letter, i) =>
    acc.concat(anagrams(str.slice(0, i) + str.slice(i + 1)).map(val => letter + val)), [])
}

/*
* 组合成包含所有组合的数组
*/
export const powerset = arr => arr.reduce((a, v) => a.concat(a.map(r => [v].concat(r))), [[]])

/*
*  RGB到十六进制
*/
export const rgbToHex = (r, g, b) => ((r << 16) + (g << 8) + b).toString(16).padStart(6, '0')

/*
*  两点之间的距离
*/
export const distance = (pos1 = {x0: 0, y0: 0}, pos2 = {x1: 0, y1: 0}) => Math.hypot(pos2.x1 - pos1.x0, pos2.y1 - pos1.y0);

/*
*  多维数组解构
*  deepFlatten([1,[2],[[3],4],5]) -> [1,2,3,4,5]
*/
export const deepFlatten = arr => arr.reduce((a, v) => a.concat(Array.isArray(v) ? deepFlatten(v) : v), [])

/**
 * @returns {String} 当前浏览器名称
 */
export const getExplorer = () => {
  const ua = window.navigator.userAgent
  const isExplorer = (exp) => {
    return ua.indexOf(exp) > -1
  }
  if (isExplorer('MSIE')) return 'IE'
  else if (isExplorer('Firefox')) return 'Firefox'
  else if (isExplorer('Chrome')) return 'Chrome'
  else if (isExplorer('Opera')) return 'Opera'
  else if (isExplorer('Safari')) return 'Safari'
}

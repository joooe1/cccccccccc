// 过滤器
const digitsRE = /(\d{3})(?=\d)/g
export default {
  fixCount(num, currency = '¥', tips = '数据加载中...') { // 金额保留2位小数
    let tmpl = num - 0;
    if (Number.isNaN(tmpl)) {
      return tips;
    } else {
      return `${currency}` + tmpl.toFixed(2);
    }
  },
  fixName(name) { // 用户名过长将被裁剪
    let tmpl = name + '';
    if (tmpl.length > 11) {
      return name.slice(0, 10);
    } else {
      return name;
    }
  },
  /**
   * 金钱过滤器
   * @param value 金额数值
   * @param currency 金钱币种标识符 默认¥
   * @param decimals 保留几位小数 默认2位小数
   * @param pos 是的金钱前后显示币种符号 1后面显示 0 在前面显示 默认在后面显示
   * @returns {string}
   * @constructor
   */
  MoneyFormat(value, pos = 1, currency = '¥', decimals = 2) {
    value = parseFloat(value)
    if (Number.isNaN(value)) {
      return '数据加载中...'
    }
    if (!isFinite(value) || (!value && value !== 0)) return ''
    var stringified = Math.abs(value).toFixed(decimals)
    var _int = decimals ? stringified.slice(0, -1 - decimals) : stringified
    var i = _int.length % 3
    var head = i > 0 ? (_int.slice(0, i) + (_int.length > 3 ? ',' : '')) : ''
    var _float = decimals ? stringified.slice(-1 - decimals) : ''
    var sign = value < 0 ? '-' : ''
    return `${sign}${!pos ? currency : ''}${head}${_int.slice(i).replace(digitsRE, '$1,')}${_float}${pos ? currency : ''}`
  }
}

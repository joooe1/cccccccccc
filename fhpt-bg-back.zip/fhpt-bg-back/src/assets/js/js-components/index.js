export default {
    install(Vue, options) {
        window._UG = options
        Vue.prototype['$ug'] = options
    }
}

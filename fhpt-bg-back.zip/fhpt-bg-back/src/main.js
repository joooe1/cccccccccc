import 'babel-polyfill';
import Vue from 'vue';
import App from './App.vue';
import router from './router';
import store from './store';
import Dayjs from 'dayjs'
import Cookie from 'js-cookie'
import filter from '@/assets/js/filter.js'
import ElementUI from 'element-ui';
import './mock';
import 'element-ui/lib/theme-chalk/index.css' // 后期cdn
import './assets/style/index.less'
import ugUtils from './axios/https/gobleUtils'
import request from './axios/https/allTypesAjax'
import UG from './axios/https/index'
import FormMaking from 'form-making'
import 'form-making/dist/FormMaking.css'
import './views/testPreview.js'

Vue.use(FormMaking)
Vue.use(ElementUI);
Vue.config.productionTip = false;
Vue.prototype.$cookie = Cookie;
Vue.prototype.$dayjs = Dayjs;
for (let i in filter) { // 添加自定义过滤器
  Vue.filter(i, filter[i])
}
Vue.use(UG, {...ugUtils, ...request});
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app');

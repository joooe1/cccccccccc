<template>
  <div class="aside-menu t-center">
    <el-menu default-active="3" class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose" :collapse="isCollapse">
      <el-submenu index="1">
        <template slot="title">
          <i class="el-icon-location"></i>
          <span slot="title">导航一</span>
        </template>
        <el-menu-item-group>
          <span slot="title">分组一</span>
          <el-menu-item index="1-1">选项1</el-menu-item>
          <el-menu-item index="1-2">选项2</el-menu-item>
        </el-menu-item-group>
        <el-menu-item-group title="分组2">
          <el-menu-item index="1-3">选项3</el-menu-item>
        </el-menu-item-group>
        <el-submenu index="1-4">
          <span slot="title">选项4</span>
          <el-menu-item index="1-4-1">选项1</el-menu-item>
        </el-submenu>
      </el-submenu>
      <el-menu-item index="2">
        <i class="el-icon-menu"></i>
        <span slot="title">导航二</span>
      </el-menu-item>
      <el-menu-item index="3">
        <i class="el-icon-document"></i>
        <span slot="title">导航三</span>
      </el-menu-item>
      <el-menu-item index="4">
        <i class="el-icon-setting"></i>
        <span slot="title">导航四</span>
      </el-menu-item>
      <el-menu-item index="5" @click="$ug.ugNextPage('/UiEdit')">
        <i class="el-icon-setting"></i>
        <span slot="title">可视化编辑</span>
      </el-menu-item>
      <el-menu-item index="6" @click="$ug.ugNextPage('/Test')">
        <i class="el-icon-setting"></i>
        <span slot="title">TestDemo</span>
      </el-menu-item>
    </el-menu>
  </div>
</template>
<script type="text/ecmascript-6">
  export default {
    name: '',
    components: {},
    data() {
      return {
        isCollapse: false
      }
    },
    created() {},
    mounted() {},
    computed: {},
    methods: {
      handleOpen(key, keyPath) {
        console.log(key, keyPath);
      },
      handleClose(key, keyPath) {
        console.log(key, keyPath);
      },
      jumpPage() {
      }
    },
    beforeDestroy() {}
  }
</script>

<style type="text/css" lang="less" scoped>
  @import '~@assets/style/color.less';
  .aside-menu{
    background: @white;
    transition: 0.3s all ease-in-out;
  }
  .el-menu li{
    text-align: left !important;
  }
  /deep/ .el-menu-vertical-demo{border: none}
</style>

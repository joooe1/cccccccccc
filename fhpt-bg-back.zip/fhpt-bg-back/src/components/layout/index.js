import AsideMenu from './AsideMenu.vue'
import TopNav from './TopNav.vue'
export {
  AsideMenu,
  TopNav
}

<template>
  <div class="top-nav-box v-middle ov-hidden afclear">
    <p class="in-block">
      <img class="v-middle" src="../../../public/static/images/center.png" height="39"/>
    </p>
    <p class="throwIcon cursor" :class="['trs0',{'trs135':translateX}]">
      <i class="iconfont iconmenu" style="font-size: 30px" @click="translate"></i>
    </p>
    <!--右边区域-->
    <div class="full-height el-col-12 fr t-right white">
      <span class="p-l10 p-b10 p-r10 p-t10" @click="jump">登录页</span>
      <span class="p-l10 p-b10 p-r10 p-t10 m-l20 m-r20" @click="$router.push('5645')">报错页</span>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  export default {
    name: '',
    components: {},
    data() {
      return {
        translateX: false
      }
    },
    created() {
    },
    mounted() {
    },
    computed: {},
    methods: {
      translate() {
        // console.log(this.$parent)
        if (this.$parent.$refs.aside.isCollapse) {
          this.$parent.$refs.aside.isCollapse = false
          this.$parent.asideWidthShrink = false
          this.translateX = false
        } else {
          this.$parent.$refs.aside.isCollapse = true
          this.$parent.asideWidthShrink = true
          this.translateX = true
        }
      },
      jump() {
        this.$ug.ugNextPage('/Login', {params: {name: '张三'}})
      }
    },
    beforeDestroy() {}
  }
</script>

<style type="text/css" lang="less" scoped>
  @import '~@assets/style/color.less';
  .top-nav-box{
    height: 60px;
    width: 100vw;
    background: @primary;
    line-height: 60px;
  }
  .trs0{
    transform: translateX(0);
  }
  .trs135{
    transform: translateX(-135px);
  }
  .throwIcon{
    width: 150px;
    margin-left: 85px;
    background: @primary;
    transition: 0.3s all ease-in-out;
  }
</style>

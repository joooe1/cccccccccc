let path = require('path');
function resolve(dir) {
  return path.join(__dirname, dir);
}
// 增加环境变量
// 获取版本信息
process.env.VUE_APP_VERSION = require('./package.json').version;
process.env.VUE_APP_BUILD_TIME = new Date();
// 压缩插件
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
// 设置gzip插件
const CompressionWebpackPlugin = require('compression-webpack-plugin');
const productionGzipExtensions = /\.(js|css|json|txt|html|ico|svg|mp3|swf|png|)(\?.*)?$/i;
module.exports = {
  publicPath: process.env.NODE_ENV === 'production' ? '/fhpt-bg/' : '/',
  // 指定生产环境目录
  outputDir: 'dist',
  // 指定生成静态资源的生成目录
  assetsDir: 'static',
  lintOnSave: 'error',
  productionSourceMap: false,
  // 在多核机器下会默认开启。
  parallel: require('os').cpus().length > 1,
  devServer: {
    host: 'localhost',
    port: 8880, // 端口号
    https: false, // https:{type:Boolean}
    // open: true, // 配置自动启动浏览器
    proxy: {
      '/fund': {
        // target: 'http://web.juhe.cn:8080/fund/findata/main', // 远程连接
        target: 'https://web.juhe.cn:8080/fund', // 远程连接
        changeOrigin: true,
        pathRewrite: {
          '^/fund': '/'
        }
      }
    }
  },
  chainWebpack: config => {
    config.plugins
      .delete('preload');
    // 忽略的打包依赖库
    // config.externals({
      // 'vue': 'Vue',
      // 'vue-router': 'VueRouter',
      // 'vuex': 'Vuex',
      // 'element-ui': 'ELEMENT',
      // 'axios': 'axios',
      // 'qs': 'Qs',
      // 'js-cookie': 'Cookies',
      // 'dayjs': 'dayjs',
      // 'muse-ui': 'MuseUI',
      // 'mockjs': 'Mock ',
      // 'better-scroll': 'BScroll'
    // })
    // 修复HMR(热更新)失效
    config.resolve.symlinks(true);
    config.resolve.alias // map 对象
      .set('@', resolve('src'))
      .set('@public', resolve('public'))
      .set('@views', resolve('src/views'))
      .set('@api', resolve('src/axios'))
      .set('@router', resolve('src/router'))
      .set('@store', resolve('src/store'))
      .set('@bcomp', resolve('src/components/business')) // 公共业务组件集合
      .set('@lcomp', resolve('src/components/layout')) // 普通UI布局组件
      .set('@assets', resolve('src/assets'))
    config.when(process.env.NODE_ENV !== 'development', config => {
      config.plugin('webpack-bundle-analyzer')
        .use(require('webpack-bundle-analyzer').BundleAnalyzerPlugin);
      config.optimization
        .minimizer([
          new UglifyJsPlugin({
            uglifyOptions: {
              compress: {
                drop_console: true,
                drop_debugger: true,
                pure_funcs: ['console.log', 'debugger']
              }
            }
          })
        ]);
    });
  },
  configureWebpack: {
    resolve: {
      alias: {
        // 可视化编辑器需要 带编辑器版本的
        'vue$': 'vue/dist/vue.esm.js'
      }
    },
    plugins: [
      // 生成gzip
      new CompressionWebpackPlugin({
        filename: '[path].gz[query]',
        algorithm: 'gzip',
        test: productionGzipExtensions,
        threshold: 10240,
        minRatio: 0.8 // 最小压缩比达到0.8时才会被压缩
      })
    ]
  }
}
